var img = document.getElementById('img');
var list = document.getElementsByClassName('ul-list');
var url = "https://qq-web.cdn-go.cn/zc.qq.com/2ac4162f/v3/img/up.png";
img.setAttribute('index', 1);
img.onclick = function() {
    if (img.getAttribute('index') == 1) {
        img.src = url;
        img.setAttribute('index', 0);
        console.log(list[0]);
        list[0].style.display = 'block';
    } else if (img.getAttribute('index') == 0) {
        img.src = 'https://qq-web.cdn-go.cn/zc.qq.com/2ac4162f/v3/img/down.png';
        img.setAttribute('index', 1);
        list[0].style.display = 'none';

    }
};
var jt = document.getElementsByClassName('jt-chinese');
var ese_list = document.getElementById('ese-list');
// jt = function() {
//     ese_list.style.display = 'none';
// }