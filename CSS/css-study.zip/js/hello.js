var a = document.getElementsByTagName('a');
console.log(a);
a[0].onclick = function() {
    console.log("你好， 世界！");
}