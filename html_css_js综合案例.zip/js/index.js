window.addEventListener('load', function() {
    function Student(sname, age) {
        this.sname = sname;
        this.age = age;
        this.study = function() {
            console.log(this.age + '岁的' +
                this.sname + '正在学习');
        };
    };
    var stu = new Student('张三', 18);
    stu.study();
});