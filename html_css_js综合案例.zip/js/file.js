// const  fs  =  require('fs');
// fs.readFile('../json/student.json',  'utf8',   (error,  doc)  =>  {    
//     if  (error  ==  null)  {
//         var students = doc.toString.;
//         //          console.log(doc);
//     } 
//     else  {        
//         console.log(err);
//     }

// });
// window.addEventListener('load', function() {
//     var tables = document.getElementById('table');
//     for (let i = 0; i < students.length; i++) {
//         var tr = document.createElement('tr');
//         tr.innerHTML = '<td>' + students[i].name + '</td>' + '<td>' + students[i].age + '</td>' + '<td>' + students[i].sex + '</td>' + '<td>' + students[i].birthday + '</td>';
//         tr.style.borderBottom = '1px solid #282C34';
//         tables.appendChild(tr);
//         // tables.insertAdjacentElement('beforeend', tr);
//     }
// });