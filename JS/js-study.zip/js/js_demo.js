// 仅当DOM加载完成时，不包括样式表、图片、flash等
// window.addEventListener('DOMContentLoaded', () => {
//     console.log('先加载DOMContentLoaded');
// });
// 页面加载事件，当文档内容完全加载时触发
// window.addEventListener('load', () => {
//     console.log('后加载onload');
// });